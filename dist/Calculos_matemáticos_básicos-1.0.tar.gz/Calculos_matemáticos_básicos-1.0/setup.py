from setuptools import setup
setup(

    name="Calculos_matemáticos_básicos",
    version="1.0",
    description="Paquete para cálculos matemáticos básicos",
    author="Jose",
    author_mail="joseacevo@gmail.com",
    url="jmagpythonist.com",
    packages=["modulos_matematicos","modulos_matematicos.Calculos_basicos"]
    

)