def suma(n1,n2):
    print("El resultado de la suma es : ", n1+n2)

def resta(n1,n2):
    print("El resultado de la resta es : ", n1-n2)

def multiplica (n1,n2):
    print("El resultado de la multiplicación es : ", n1*n2)

def divide(n1,n2):
    print("El resultado de la división es : ", n1/n2)


